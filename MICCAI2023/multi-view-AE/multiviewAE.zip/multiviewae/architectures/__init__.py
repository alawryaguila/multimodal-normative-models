from .mlp import *
from .cnn import *

__all__ = ["Encoder", "VariationalEncoder", "Decoder", "VariationalDecoder", "Discriminator"]
classes = __all__ 

#TODO: use constants instead